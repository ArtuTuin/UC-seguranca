public class Impressora {
    public static void imprimir(String titulo, byte[] dados) {
        System.out.println(titulo);
        for (byte b : dados) {
            System.out.print((char) b);
        }
        System.out.println("\n---");
    }
}