import java.io.*;
import java.util.Random;

public class CryptoDummy {
    private static final String KEY_FILE = "chave.dummy";

    public static byte[] cifrar(byte[] textoClaro) throws IOException {
        Random random = new Random();
        int chave = random.nextInt(256);

        try (FileWriter fw = new FileWriter(KEY_FILE)) {
            fw.write(Integer.toString(chave));
        }

        byte[] textoCifrado = new byte[textoClaro.length];
        for (int i = 0; i < textoClaro.length; i++) {
            textoCifrado[i] = (byte) (textoClaro[i] + chave);
        }

        return textoCifrado;
    }

    public static byte[] decifrar(byte[] textoCifrado) throws IOException {
        int chave;

        try (BufferedReader br = new BufferedReader(new FileReader(KEY_FILE))) {
            chave = Integer.parseInt(br.readLine());
        }

        byte[] textoClaro = new byte[textoCifrado.length];
        for (int i = 0; i < textoCifrado.length; i++) {
            textoClaro[i] = (byte) (textoCifrado[i] - chave);
        }

        return textoClaro;
    }
}