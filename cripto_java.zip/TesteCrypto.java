public class TesteCrypto {
    public static void main(String[] args) throws Exception {
        String texto = "Mensagem secreta!";
        byte[] textoClaro = texto.getBytes();

        // Dummy
        byte[] dummyCifrado = CryptoDummy.cifrar(textoClaro);
        byte[] dummyDecifrado = CryptoDummy.decifrar(dummyCifrado);
        Impressora.imprimir("Dummy - Cifrado:", dummyCifrado);
        Impressora.imprimir("Dummy - Decifrado:", dummyDecifrado);

        // AES
        byte[] aesCifrado = CryptoAES.cifrar(textoClaro);
        byte[] aesDecifrado = CryptoAES.decifrar(aesCifrado);
        Impressora.imprimir("AES - Cifrado:", aesCifrado);
        Impressora.imprimir("AES - Decifrado:", aesDecifrado);

        // RSA
        byte[] rsaCifrado = CryptoRSA.cifrar(textoClaro);
        byte[] rsaDecifrado = CryptoRSA.decifrar(rsaCifrado);
        Impressora.imprimir("RSA - Cifrado:", rsaCifrado);
        Impressora.imprimir("RSA - Decifrado:", rsaDecifrado);
    }
}