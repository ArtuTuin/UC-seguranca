import java.io.*;
import java.security.*;
import java.security.spec.*;
import javax.crypto.Cipher;

public class CryptoRSA {
    private static final String PUBLIC_KEY_FILE = "chave.publica";
    private static final String PRIVATE_KEY_FILE = "chave.privada";

    public static byte[] cifrar(byte[] textoClaro) throws Exception {
        KeyPair keyPair = gerarChaves();

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.ENCRYPT_MODE, keyPair.getPublic());
        return cipher.doFinal(textoClaro);
    }

    public static byte[] decifrar(byte[] textoCifrado) throws Exception {
        PrivateKey privateKey = lerChavePrivada();

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        return cipher.doFinal(textoCifrado);
    }

    private static KeyPair gerarChaves() throws Exception {
        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(1024);
        KeyPair pair = gen.generateKeyPair();

        try (FileOutputStream pubOut = new FileOutputStream(PUBLIC_KEY_FILE)) {
            pubOut.write(pair.getPublic().getEncoded());
        }
        try (FileOutputStream privOut = new FileOutputStream(PRIVATE_KEY_FILE)) {
            privOut.write(pair.getPrivate().getEncoded());
        }

        return pair;
    }

    private static PrivateKey lerChavePrivada() throws Exception {
        byte[] keyBytes = new byte[1024];
        try (FileInputStream fis = new FileInputStream(PRIVATE_KEY_FILE)) {
            fis.read(keyBytes);
        }

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        return factory.generatePrivate(spec);
    }
}