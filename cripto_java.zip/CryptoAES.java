import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.security.SecureRandom;

public class CryptoAES {
    private static final String KEY_FILE = "chave.simetrica";

    public static byte[] cifrar(byte[] textoClaro) throws Exception {
        SecretKey key = gerarChave();
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return cipher.doFinal(textoClaro);
    }

    public static byte[] decifrar(byte[] textoCifrado) throws Exception {
        SecretKey key = lerChave();
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        return cipher.doFinal(textoCifrado);
    }

    private static SecretKey gerarChave() throws Exception {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128, new SecureRandom());
        SecretKey key = keyGen.generateKey();

        try (FileOutputStream fos = new FileOutputStream(KEY_FILE)) {
            fos.write(key.getEncoded());
        }

        return key;
    }

    private static SecretKey lerChave() throws Exception {
        byte[] keyBytes = new byte[16];
        try (FileInputStream fis = new FileInputStream(KEY_FILE)) {
            fis.read(keyBytes);
        }
        return new SecretKeySpec(keyBytes, "AES");
    }
}